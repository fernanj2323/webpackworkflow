export default [ 
{
	title: 'Home',
	url: '/'
}, 
{
	title: 'Task',
	url: '/task',
},
{
 	title: 'User',
 	url: '/User'
},
{
	title: 'Contact Us', 
	url: '/contact'
	}
];