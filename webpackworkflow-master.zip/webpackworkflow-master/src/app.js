// aqui es donde se carga todo webpack 
// anteriormente pensabamos que la aplicacion cargaba desde index.html
// pero en el caso de webpack carga desde app.js 
require('./styles/main.css');
import('./static/logo.jpg');
/*alert('works');*/